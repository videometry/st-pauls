@echo off
echo ==========================================================================
echo Compiling St. Paul's After Effects Master + 12 Section .AEP and .AET Files
echo ==========================================================================
set "AE_EXE=C:\Program Files\Adobe\Adobe After Effects 2026\Support Files\AfterFX.exe"
if not exist "%AE_EXE%" set "AE_EXE=C:\Program Files\Adobe\Adobe After Effects 2025\Support Files\AfterFX.exe"
echo Building Build_St_Pauls_MASTER_10m45s_All_5_Outputs_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Build_St_Pauls_MASTER_10m45s_All_5_Outputs_AE.jsx"
echo Building Build_SEC01_Creation_50s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC01_Creation_50s_AE.jsx"
echo Building Build_SEC02_Blooming_Botanical_55s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC02_Blooming_Botanical_55s_AE.jsx"
echo Building Build_SEC03_Domination_40s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC03_Domination_40s_AE.jsx"
echo Building Build_SEC04_Separation_Richmond_Planet_40s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC04_Separation_Richmond_Planet_40s_AE.jsx"
echo Building Build_SEC05_Community_Fulton_Clinic_50s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC05_Community_Fulton_Clinic_50s_AE.jsx"
echo Building Build_SEC06_Questioning_Sacred_Geometry_55s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC06_Questioning_Sacred_Geometry_55s_AE.jsx"
echo Building Build_SEC07_Diversity_Spong_Interfaith_60s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC07_Diversity_Spong_Interfaith_60s_AE.jsx"
echo Building Build_SEC08_Equality_Womens_Leadership_60s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC08_Equality_Womens_Leadership_60s_AE.jsx"
echo Building Build_SEC09_Inclusivity_Tapestry_Quilt_60s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC09_Inclusivity_Tapestry_Quilt_60s_AE.jsx"
echo Building Build_SEC10_Truth_Telling_Reckoning_60s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC10_Truth_Telling_Reckoning_60s_AE.jsx"
echo Building Build_SEC11_Hope_Butterflies_Mosaic_60s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC11_Hope_Butterflies_Mosaic_60s_AE.jsx"
echo Building Build_SEC12_The_Close_Altar_Mosaic_55s_AE...
"%AE_EXE%" -r "%~dp001_After_Effects_Templates_JSX_AEP_AET\Per_Section_AE_Templates\Build_SEC12_The_Close_Altar_Mosaic_55s_AE.jsx"
echo [DONE] All .AEP and .AET After Effects Projects & Templates saved!
pause