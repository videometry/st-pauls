/*
 * Build_STUDY04_1000_Block_Harmonic_Dissolution_60s_AE.jsx
 * St. Paul's Sacred Harmonics & World Geometry Meditation — After Effects Project & Template Compiler
 * Run via: File > Scripts > Run Script File...
 */
(function() {
    var CFG = {
  "projectName": "STUDY04_1000_Block_Harmonic_Dissolution_60s",
  "fps": 24,
  "durationSec": 60,
  "relToRoot": "../../..",
  "media": {
    "z2": "10_Sacred_Harmonics_and_Geometry_Meditation/03_Experimental_60s_Studies_Projector_Outputs/STUDY04_1000_Block_Harmonic_Dissolution/STUDY04_1000_Block_Harmonic_Dissolution_Z2_Center_Medallion_16x9.mp4",
    "z3": "10_Sacred_Harmonics_and_Geometry_Meditation/03_Experimental_60s_Studies_Projector_Outputs/STUDY04_1000_Block_Harmonic_Dissolution/STUDY04_1000_Block_Harmonic_Dissolution_Z3_Far_Ceiling_Vault_16x9.mp4",
    "z1": "10_Sacred_Harmonics_and_Geometry_Meditation/03_Experimental_60s_Studies_Projector_Outputs/STUDY04_1000_Block_Harmonic_Dissolution/STUDY04_1000_Block_Harmonic_Dissolution_Z1_Chancel_Backdrop_16x9.mp4",
    "z1a": "10_Sacred_Harmonics_and_Geometry_Meditation/03_Experimental_60s_Studies_Projector_Outputs/STUDY04_1000_Block_Harmonic_Dissolution/STUDY04_1000_Block_Harmonic_Dissolution_Z1A_Left_Slice_9x16.mp4",
    "z1b": "10_Sacred_Harmonics_and_Geometry_Meditation/03_Experimental_60s_Studies_Projector_Outputs/STUDY04_1000_Block_Harmonic_Dissolution/STUDY04_1000_Block_Harmonic_Dissolution_Z1B_Center_Slice_9x16.mp4",
    "z1c": "10_Sacred_Harmonics_and_Geometry_Meditation/03_Experimental_60s_Studies_Projector_Outputs/STUDY04_1000_Block_Harmonic_Dissolution/STUDY04_1000_Block_Harmonic_Dissolution_Z1C_Right_Slice_9x16.mp4"
  },
  "audio": "10_Sacred_Harmonics_and_Geometry_Meditation/01_Audio_Score_and_1000_Note_Manifest/STUDY04_1000_Block_Harmonic_Dissolution_60s_48kHz.wav",
  "guides": {
    "z2": "01_Projection_Templates_For_Animation/02_Center_Ceiling_Medallion_16x9/Masks_and_Overlays/Medallion_Overlay_Architectural_LineArt_1920x1080.png",
    "z3": "01_Projection_Templates_For_Animation/03_Far_Ceiling_Chancel_Vault_16x9/Masks_and_Overlays/Far_Ceiling_Overlay_Architectural_LineArt_1920x1080.png",
    "z1a": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Overlay_Architectural_LineArt_01_Left_1080x1920.png",
    "z1b": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Overlay_Architectural_LineArt_02_Center_1080x1920.png",
    "z1c": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Overlay_Architectural_LineArt_03_Right_1080x1920.png"
  }
};
    app.beginUndoGroup("Build " + CFG.projectName);
    if (app.project) { app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES); }
    app.newProject();
    app.project.bitsPerChannel = 16;

    var scriptFolder = File($.fileName).parent;
    var rootFolder = Folder(scriptFolder.fsName + "/" + CFG.relToRoot);

    function importRel(rel) {
        var f = new File(rootFolder.fsName + "/" + rel);
        if (!f.exists) { throw new Error("Missing asset: " + f.fsName); }
        return app.project.importFile(new ImportOptions(f));
    }

    var fMedia = app.project.items.addFolder("01_SACRED_HARMONICS_MEDIA");
    var fComps = app.project.items.addFolder("00_PROJECTOR_OUTPUT_COMPS");

    var itAudio = importRel(CFG.audio); itAudio.parentFolder = fMedia;
    var items = {}, guides = {};
    for (var k in CFG.media) { items[k] = importRel(CFG.media[k]); items[k].parentFolder = fMedia; }
    for (var g in CFG.guides) { guides[g] = importRel(CFG.guides[g]); guides[g].parentFolder = fMedia; }

    function makeOutComp(name, key, w, h) {
        var c = app.project.items.addComp(name, w, h, 1.0, CFG.durationSec, CFG.fps);
        c.parentFolder = fComps;
        var lAud = c.layers.add(itAudio); lAud.audioEnabled = true;
        var lVid = c.layers.add(items[key]); lVid.audioEnabled = false;
        var sx = 100.0 * (w / items[key].width), sy = 100.0 * (h / items[key].height);
        var s = Math.min(sx, sy);
        lVid.property("Scale").setValue([s, s]);
        if (guides[key]) {
            var lG = c.layers.add(guides[key]);
            lG.guideLayer = true;
            lG.opacity.setValue(35);
        }
        return c;
    }

    var cZ2  = makeOutComp("01_OUT1_Zone2_Center_Medallion_1920x1080", "z2", 1920, 1080);
    var cZ3  = makeOutComp("02_OUT2_Zone3_Far_Ceiling_Vault_1920x1080", "z3", 1920, 1080);
    var cZ1A = makeOutComp("03_OUT3_Zone1A_Left_Slice_1080x1920", "z1a", 1080, 1920);
    var cZ1B = makeOutComp("04_OUT4_Zone1B_Center_Slice_1080x1920", "z1b", 1080, 1920);
    var cZ1C = makeOutComp("05_OUT5_Zone1C_Right_Slice_1080x1920", "z1c", 1080, 1920);

    var cStage = app.project.items.addComp("00_STAGE_5Outputs_9x16_1080x1920", 1080, 1920, 1.0, CFG.durationSec, CFG.fps);
    cStage.parentFolder = fComps;
    cStage.layers.add(itAudio);

    function placeInStage(comp, x0, y0, tw, th) {
        var L = cStage.layers.add(comp);
        L.audioEnabled = false;
        var s = 100.0 * (tw / comp.width);
        L.property("Scale").setValue([s, s]);
        L.property("Position").setValue([x0 + tw * 0.5, y0 + th * 0.5]);
    }
    placeInStage(cZ2,  220, 130, 640, 360);
    placeInStage(cZ3,  116, 536, 848, 477);
    placeInStage(cZ1A,  34, 1062, 333, 592);
    placeInStage(cZ1B, 373, 1062, 333, 592);
    placeInStage(cZ1C, 712, 1062, 333, 592);

    var outAep = new File(scriptFolder.fsName + "/" + CFG.projectName + ".aep");
    var outAet = new File(scriptFolder.fsName + "/" + CFG.projectName + ".aet");
    app.project.save(outAep);
    app.project.save(outAet);
    app.endUndoGroup();
})();
