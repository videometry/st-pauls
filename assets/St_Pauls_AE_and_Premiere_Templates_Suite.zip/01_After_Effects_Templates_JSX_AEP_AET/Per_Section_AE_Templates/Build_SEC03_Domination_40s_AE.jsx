/*
 * Build_SEC03_Domination_40s_AE.jsx
 * ============================================================================
 * St. Paul's Visual Experience — Auto-Generated After Effects Project & Template Compiler
 * Run in After Effects via: File > Scripts > Run Script File...
 * Automatically constructs all 5 Projector Output Comps, the 3240x1920 Full Chancel Work Comp,
 * the 1080x1920 (9:16) Unified 5-Output Sanctuary Stage Visualizer Comp, Alpha Track Mattes,
 * Architectural Guide Layers, Shared Bridge Keyframes (B00-B12), Comp Markers, and Continuous
 * D-Modal Audio, then saves BOTH `SEC03_Domination_40s.aep` and `SEC03_Domination_40s.aet`!
 */
(function() {
    var CFG = {
  "projectName": "SEC03_Domination_40s",
  "isMaster": false,
  "fps": 24,
  "relToRoot": "../../..",
  "arch": {
    "z2_template": "01_Projection_Templates_For_Animation/02_Center_Ceiling_Medallion_16x9/St Pauls Ceiling Template v_01.png",
    "z2_lineart": "01_Projection_Templates_For_Animation/02_Center_Ceiling_Medallion_16x9/Masks_and_Overlays/Medallion_Overlay_Architectural_LineArt_1920x1080.png",
    "z2_mask_core": "01_Projection_Templates_For_Animation/02_Center_Ceiling_Medallion_16x9/Masks_and_Overlays/Medallion_Mask_03_Inner_Sunburst_Core_1920x1080.png",
    "z2_mask_wheel": "01_Projection_Templates_For_Animation/02_Center_Ceiling_Medallion_16x9/Masks_and_Overlays/Medallion_Mask_05_Outer_Coffered_Wheel_Ring_1920x1080.png",
    "z2_id_matte": "01_Projection_Templates_For_Animation/02_Center_Ceiling_Medallion_16x9/Masks_and_Overlays/Medallion_RGB_ID_Matte_1920x1080.png",
    "z3_template": "01_Projection_Templates_For_Animation/03_Far_Ceiling_Chancel_Vault_16x9/St Pauls FAR Ceiling Template v_01_1920x1080.png",
    "z3_lineart": "01_Projection_Templates_For_Animation/03_Far_Ceiling_Chancel_Vault_16x9/Masks_and_Overlays/Far_Ceiling_Overlay_Architectural_LineArt_1920x1080.png",
    "z3_mask_beam": "01_Projection_Templates_For_Animation/03_Far_Ceiling_Chancel_Vault_16x9/Masks_and_Overlays/Far_Ceiling_Mask_01_Top_Horizontal_Beam_1920x1080.png",
    "z3_mask_vault": "01_Projection_Templates_For_Animation/03_Far_Ceiling_Chancel_Vault_16x9/Masks_and_Overlays/Far_Ceiling_Mask_02_Full_Coffer_Vault_1920x1080.png",
    "z3_mask_center": "01_Projection_Templates_For_Animation/03_Far_Ceiling_Chancel_Vault_16x9/Masks_and_Overlays/Far_Ceiling_Mask_03_Center_Large_Coffer_1920x1080.png",
    "z3_mask_perim": "01_Projection_Templates_For_Animation/03_Far_Ceiling_Chancel_Vault_16x9/Masks_and_Overlays/Far_Ceiling_Mask_04_Eight_Perimeter_Coffers_1920x1080.png",
    "z3_mask_ribs": "01_Projection_Templates_For_Animation/03_Far_Ceiling_Chancel_Vault_16x9/Masks_and_Overlays/Far_Ceiling_Mask_05_Coffer_Ribs_and_Stiles_Only_1920x1080.png",
    "z3_id_matte": "01_Projection_Templates_For_Animation/03_Far_Ceiling_Chancel_Vault_16x9/Masks_and_Overlays/Far_Ceiling_RGB_ID_Matte_1920x1080.png",
    "z1_template": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Backdrop Blend v2_Half_3240x1920.png",
    "z1_mask_walls": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Mask_01_Walls_Only_No_Windows_Columns_3240x1920.png",
    "z1_mask_windows": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Mask_02_Three_Stained_Glass_Windows_3240x1920.png",
    "z1_mask_mosaic": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Mask_03_Tiffany_Last_Supper_Mosaic_3240x1920.png",
    "z1_mask_reredos": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Mask_04_Marble_Reredos_and_Altar_3240x1920.png",
    "z1_mask_columns": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Mask_05_Four_Corinthian_Columns_3240x1920.png",
    "z1a_lineart": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Overlay_Architectural_LineArt_01_Left_1080x1920.png",
    "z1b_lineart": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Overlay_Architectural_LineArt_02_Center_1080x1920.png",
    "z1c_lineart": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Overlay_Architectural_LineArt_03_Right_1080x1920.png",
    "z1a_mask_walls": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Mask_01_Walls_Only_No_Windows_Columns_01_Left_1080x1920.png",
    "z1b_mask_walls": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Mask_01_Walls_Only_No_Windows_Columns_02_Center_1080x1920.png",
    "z1c_mask_walls": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Mask_01_Walls_Only_No_Windows_Columns_03_Right_1080x1920.png",
    "z1b_mask_mosaic": "01_Projection_Templates_For_Animation/01_Backdrop_Chancel_Wall/Masks_and_Overlays/Backdrop_Mask_03_Tiffany_Last_Supper_Mosaic_02_Center_1080x1920.png"
  },
  "masterAudioWav": "08_Master_Continuous_Show_10m45s/01_Master_Soundtrack_v2_Continuous/St_Pauls_10m45s_Master_Continuous_Soundtrack_v2_48kHz.wav",
  "sundayWashMp3": "08_Master_Continuous_Show_10m45s/01_Master_Soundtrack_v2_Continuous/St_Pauls_Sunday_Morning_Ambient_Sound_Wash_v2.mp3",
  "sections": [
    {
      "num": "03",
      "code": "SEC03",
      "slug": "SEC03_Domination_40s",
      "title": "Domination: 1865 Tall Steeple & Human Dignity",
      "start": 105,
      "end": 145,
      "dur": 40,
      "b_in": "B02",
      "b_in_dir": "B02_01m45s",
      "b_out": "B03",
      "b_out_dir": "B03_02m25s",
      "mode": "D Minor / Aeolian",
      "audio_stem": "08_Master_Continuous_Show_10m45s/01_Master_Soundtrack_v2_Continuous/Individual_Section_Stems/Sec_03_Domination_40s_ContinuousSlice.mp3",
      "archives": [
        "08_Master_Continuous_Show_10m45s/03_Processed_St_Pauls_Archives_Plates/Archive_Sec03_1865_Tall_Steeple_and_Civil_War_Tent.jpg",
        "08_Master_Continuous_Show_10m45s/03_Processed_St_Pauls_Archives_Plates/Archive_Sec03_Original_Tall_Steeple_Winter_View.jpg",
        "08_Master_Continuous_Show_10m45s/03_Processed_St_Pauls_Archives_Plates/Archive_Sec03_19th_Century_Vestry_Portrait.jpg"
      ],
      "media": {
        "z2": {
          "rel": "08_Master_Continuous_Show_10m45s/04_Bridged_Section_Masters/SEC03_Z2_Center_Medallion_16x9.mp4",
          "is_video": true
        },
        "z3": {
          "rel": "08_Master_Continuous_Show_10m45s/04_Bridged_Section_Masters/SEC03_Z3_Far_Ceiling_Vault_16x9.mp4",
          "is_video": true
        },
        "z1": {
          "rel": "08_Master_Continuous_Show_10m45s/04_Bridged_Section_Masters/SEC03_Z1_Chancel_Backdrop_16x9.mp4",
          "is_video": true
        },
        "z1a": {
          "rel": "08_Master_Continuous_Show_10m45s/04_Bridged_Section_Masters/SEC03_Z1A_Left_Slice_9x16.mp4",
          "is_video": true
        },
        "z1b": {
          "rel": "08_Master_Continuous_Show_10m45s/04_Bridged_Section_Masters/SEC03_Z1B_Center_Slice_9x16.mp4",
          "is_video": true
        },
        "z1c": {
          "rel": "08_Master_Continuous_Show_10m45s/04_Bridged_Section_Masters/SEC03_Z1C_Right_Slice_9x16.mp4",
          "is_video": true
        }
      },
      "segments": []
    }
  ]
};

    app.beginSuppressDialogs();
    app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES);
    var proj = app.newProject();
    proj.bitsPerChannel = 8;

    var scriptFile = new File($.fileName);
    var scriptFolder = scriptFile.parent;
    var rootFolder = new Folder(scriptFolder.fsName + "/" + CFG.relToRoot);
    var rootPath = rootFolder.fsName.replace(/\\/g, "/");
    if (!File(rootPath + "/01_Projection_Templates_For_Animation/All_Zones_Masks_and_RGB_ID_Overview.jpg").exists) {
        rootPath = "C:/VV/St_Pauls_Visual_Experience";
    }

    // Create organized Project Panel Bins
    var binDeliverables = proj.items.addFolder("00_MASTER_DELIVERABLE_COMPS_5_OUTPUTS_AND_STAGE");
    var binPrecomps     = proj.items.addFolder("01_SECTION_ZONE_PRECOMPS");
    var binTemplates    = proj.items.addFolder("02_ARCHITECTURAL_TEMPLATES_AND_ALPHA_MASKS");
    var binAudio        = proj.items.addFolder("03_AUDIO_CONTINUOUS_D_MODAL_SCORE_v2");
    var binBridges      = proj.items.addFolder("04_SHARED_BRIDGE_KEYFRAMES_B00_TO_B12");
    var binFootage      = proj.items.addFolder("05_VEO_LOOPS_STYLEFRAMES_AND_ARCHIVES");

    var importedCache = {};
    function importAsset(relPath, targetBin, loopCount) {
        if (!relPath) return null;
        if (importedCache[relPath]) return importedCache[relPath];
        var f = new File(rootPath + "/" + relPath);
        if (!f.exists) return null;
        var io = new ImportOptions(f);
        var item = proj.importFile(io);
        if (targetBin) item.parentFolder = targetBin;
        if (loopCount && loopCount > 1 && item.mainSource && !item.mainSource.isStill) {
            try { item.mainSource.loop = loopCount; } catch (e) {}
        }
        importedCache[relPath] = item;
        return item;
    }

    function fitLayerToComp(layer, compW, compH, mode) {
        if (!layer || !layer.source) return;
        var sw = layer.source.width || compW;
        var sh = layer.source.height || compH;
        var sx = (compW / sw) * 100.0;
        var sy = (compH / sh) * 100.0;
        var s = (mode === "cover") ? Math.max(sx, sy) : Math.min(sx, sy);
        layer.property("ADBE Transform Group").property("ADBE Scale").setValue([s, s]);
        layer.property("ADBE Transform Group").property("ADBE Position").setValue([compW * 0.5, compH * 0.5]);
    }

    function applyAlphaMatte(contentLayer, matteLayer) {
        if (!contentLayer || !matteLayer) return;
        try {
            if (typeof contentLayer.setTrackMatte === "function") {
                matteLayer.enabled = false;
                contentLayer.setTrackMatte(matteLayer, TrackMatteType.ALPHA);
            } else {
                matteLayer.moveBefore(contentLayer);
                contentLayer.trackMatteType = TrackMatteType.ALPHA;
            }
        } catch (e) {}
    }

    function addCompMarker(comp, timeSec, commentText, durSec) {
        try {
            var mv = new MarkerValue(commentText);
            if (durSec && durSec > 0) mv.duration = durSec;
            comp.markerProperty.setValueAtTime(Math.max(0, timeSec), mv);
        } catch (e) {}
    }

    // Import core architectural templates, line-art guides, and alpha masks
    var archItems = {};
    for (var ak in CFG.arch) {
        if (CFG.arch.hasOwnProperty(ak)) {
            archItems[ak] = importAsset(CFG.arch[ak], binTemplates, 1);
        }
    }

    // Build Per-Section Zone Precomps (Zone 2 1920x1080, Zone 3 1920x1080, Zone 1 Full Chancel 3240x1920)
    var tOffset = CFG.sections[0].start;
    var totalDur = CFG.sections[CFG.sections.length - 1].end - tOffset;
    var secPrecomps = [];

    for (var i = 0; i < CFG.sections.length; i++) {
        var sec = CFG.sections[i];
        var sDur = sec.dur;
        var secFolder = proj.items.addFolder("Sec_" + sec.num + "_" + sec.code + " (" + sDur + "s)");
        secFolder.parentFolder = binPrecomps;

        // Import raw VV Loop Assembler segments into Footage bin if available
        if (sec.segments && sec.segments.length > 0) {
            var segBin = proj.items.addFolder(sec.code + "_VV_Loop_Assembler_Segments");
            segBin.parentFolder = binFootage;
            for (var sg = 0; sg < sec.segments.length; sg++) {
                importAsset(sec.segments[sg], segBin, 1);
            }
        }

        var zoneSpecs = [
            { key: "z2", name: sec.code + "_Z2_Center_Medallion_1920x1080", w: 1920, h: 1080, lineart: archItems.z2_lineart, mask: archItems.z2_mask_core, bSuffix: "Z2_Center_Medallion" },
            { key: "z3", name: sec.code + "_Z3_Far_Ceiling_Vault_1920x1080", w: 1920, h: 1080, lineart: archItems.z3_lineart, mask: archItems.z3_mask_center, bSuffix: "Z3_Far_Ceiling_Vault" },
            { key: "z1", name: sec.code + "_Z1_Full_Chancel_3240x1920", w: 3240, h: 1920, lineart: archItems.z1_template, mask: (sec.num === "12" ? archItems.z1_mask_mosaic : archItems.z1_mask_walls), bSuffix: "Z1_Chancel_Backdrop" }
        ];

        var builtZones = {};
        for (var z = 0; z < zoneSpecs.length; z++) {
            var zs = zoneSpecs[z];
            var zComp = proj.items.addComp(zs.name, zs.w, zs.h, 1.0, sDur, CFG.fps);
            zComp.parentFolder = secFolder;

            // 1. Bottom Layer: Layer 1 Veo 3.1 Living Architecture Loop (or Zone Concept Styleframe)
            var mInfo = sec.media[zs.key];
            if (mInfo && mInfo.rel) {
                var baseItem = importAsset(mInfo.rel, binFootage, 20);
                if (baseItem) {
                    var baseLayer = zComp.layers.add(baseItem);
                    baseLayer.name = "Layer1_Veo_Living_Architecture__" + baseItem.name;
                    baseLayer.outPoint = sDur;
                    fitLayerToComp(baseLayer, zs.w, zs.h, "cover");
                }
            }

            // 2. Middle Layer: Layer 2 Alpha-Masked St. Paul's Archival Plate (on historical sections)
            if (sec.archives && sec.archives.length > 0 && (zs.key === "z1" || zs.key === "z3")) {
                var archPlateItem = importAsset(sec.archives[0], binFootage, 1);
                if (archPlateItem && zs.mask) {
                    var archLayer = zComp.layers.add(archPlateItem);
                    archLayer.name = "Layer2_Masked_Archive__" + archPlateItem.name;
                    archLayer.startTime = 2.0;
                    archLayer.inPoint = 2.0;
                    archLayer.outPoint = Math.max(4.0, sDur - 2.0);
                    fitLayerToComp(archLayer, zs.w, zs.h, "contain");
                    archLayer.property("ADBE Transform Group").property("ADBE Opacity").setValue(88);

                    var matteLayer = zComp.layers.add(zs.mask);
                    matteLayer.name = "AlphaMatte__" + zs.mask.name;
                    fitLayerToComp(matteLayer, zs.w, zs.h, "contain");
                    applyAlphaMatte(archLayer, matteLayer);
                }
            }

            // 3. Entry & Exit Shared Bridge Keyframe Reference Guide Layers (B(k-1) at 0s, B(k) at end)
            var bInRel  = "08_Master_Continuous_Show_10m45s/02_Shared_Bridge_Keyframes_B00_to_B12/" + sec.b_in_dir  + "/" + sec.b_in  + "_" + zs.bSuffix + "_1280x720.png";
            var bOutRel = "08_Master_Continuous_Show_10m45s/02_Shared_Bridge_Keyframes_B00_to_B12/" + sec.b_out_dir + "/" + sec.b_out + "_" + zs.bSuffix + "_1280x720.png";
            var bInItem  = importAsset(bInRel, binBridges, 1);
            var bOutItem = importAsset(bOutRel, binBridges, 1);
            if (bOutItem) {
                var lOut = zComp.layers.add(bOutItem);
                lOut.name = "GUIDE_Exit_Bridge_" + sec.b_out + " (Toggle Eye to Verify End Lock)";
                lOut.guideLayer = true;
                lOut.enabled = false;
                lOut.inPoint = Math.max(0, sDur - 1.0);
                lOut.outPoint = sDur;
                fitLayerToComp(lOut, zs.w, zs.h, "cover");
            }
            if (bInItem) {
                var lIn = zComp.layers.add(bInItem);
                lIn.name = "GUIDE_Entry_Bridge_" + sec.b_in + " (Toggle Eye to Verify Start Lock)";
                lIn.guideLayer = true;
                lIn.enabled = false;
                lIn.inPoint = 0;
                lIn.outPoint = Math.min(sDur, 1.0);
                fitLayerToComp(lIn, zs.w, zs.h, "cover");
            }

            // 4. Top Guide Layer: Architectural Line-Art Overlay (guideLayer=true so NEVER rendered by accident!)
            if (zs.lineart) {
                var gLayer = zComp.layers.add(zs.lineart);
                gLayer.name = "GUIDE_Architectural_Geometry (Guide Layer - Excluded From Render)";
                gLayer.guideLayer = true;
                gLayer.enabled = (zs.key !== "z1"); // LineArt visible at 35% on Z2/Z3; full photo template muted on Z1
                gLayer.property("ADBE Transform Group").property("ADBE Opacity").setValue(35);
                fitLayerToComp(gLayer, zs.w, zs.h, "contain");
                gLayer.locked = true;
            }

            addCompMarker(zComp, 0, "ENTRY " + sec.b_in + " | Sec " + sec.num + ": " + sec.title, 0);
            addCompMarker(zComp, sDur - (1.0 / CFG.fps), "EXIT " + sec.b_out, 0);
            builtZones[zs.key] = zComp;
        }
        secPrecomps.push({ sec: sec, comps: builtZones });
    }

    // Assemble Master Deliverable Comps
    var compOut1 = proj.items.addComp("01_OUTPUT_1_Zone2_Center_Medallion_1920x1080", 1920, 1080, 1.0, totalDur, CFG.fps);
    var compOut2 = proj.items.addComp("02_OUTPUT_2_Zone3_Far_Ceiling_Vault_1920x1080", 1920, 1080, 1.0, totalDur, CFG.fps);
    var compZ1Work = proj.items.addComp("06_WORK_CANVAS_Zone1_Full_Chancel_3240x1920", 3240, 1920, 1.0, totalDur, CFG.fps);
    compOut1.parentFolder = binDeliverables;
    compOut2.parentFolder = binDeliverables;
    compZ1Work.parentFolder = binDeliverables;

    for (var s = 0; s < secPrecomps.length; s++) {
        var sp = secPrecomps[s];
        var relStart = sp.sec.start - tOffset;
        var l1 = compOut1.layers.add(sp.comps.z2);
        l1.startTime = relStart;
        var l2 = compOut2.layers.add(sp.comps.z3);
        l2.startTime = relStart;
        var lW = compZ1Work.layers.add(sp.comps.z1);
        lW.startTime = relStart;

        var mLabel = sp.sec.b_in + " -> Sec " + sp.sec.num + " (" + sp.sec.dur + "s | " + sp.sec.mode + ")";
        addCompMarker(compOut1, relStart, mLabel, sp.sec.dur);
        addCompMarker(compOut2, relStart, mLabel, sp.sec.dur);
        addCompMarker(compZ1Work, relStart, mLabel, sp.sec.dur);
    }

    // Outputs 3, 4, 5: Auto-cropped 1080x1920 (9:16) Vertical Slices driven live by compZ1Work (3240x1920)!
    var sliceDefs = [
        { name: "03_OUTPUT_3_Zone1A_Left_Wall_Slice_1080x1920",   posX: 1620, guide: archItems.z1a_lineart },
        { name: "04_OUTPUT_4_Zone1B_Center_Altar_Slice_1080x1920", posX: 540,  guide: archItems.z1b_lineart },
        { name: "05_OUTPUT_5_Zone1C_Right_Wall_Slice_1080x1920",  posX: -540, guide: archItems.z1c_lineart }
    ];
    var sliceComps = [];
    for (var sl = 0; sl < sliceDefs.length; sl++) {
        var sd = sliceDefs[sl];
        var sc = proj.items.addComp(sd.name, 1080, 1920, 1.0, totalDur, CFG.fps);
        sc.parentFolder = binDeliverables;
        var wLayer = sc.layers.add(compZ1Work);
        wLayer.property("ADBE Transform Group").property("ADBE Position").setValue([sd.posX, 960]);
        if (sd.guide) {
            var sgLayer = sc.layers.add(sd.guide);
            sgLayer.name = "GUIDE_Slice_LineArt (Excluded From Render)";
            sgLayer.guideLayer = true;
            sgLayer.property("ADBE Transform Group").property("ADBE Opacity").setValue(30);
            sgLayer.locked = true;
        }
        sliceComps.push(sc);
    }

    // 00_STAGE_VISUALIZER_9x16_All_5_Outputs_1080x1920 (1:1 Un-stretched Unified Sanctuary Stage!)
    var compStage = proj.items.addComp("00_STAGE_VISUALIZER_9x16_All_5_Outputs_1080x1920", 1080, 1920, 1.0, totalDur, CFG.fps);
    compStage.parentFolder = binDeliverables;
    var bgSolid = compStage.layers.addSolid([0.03, 0.04, 0.06], "Sanctuary_Dark_Stage_BG", 1080, 1920, 1.0, totalDur);
    bgSolid.locked = true;

    function placeOnStage(compItem, x0, y0, tw, th) {
        var lyr = compStage.layers.add(compItem);
        var scPct = (tw / compItem.width) * 100.0;
        lyr.property("ADBE Transform Group").property("ADBE Scale").setValue([scPct, scPct]);
        lyr.property("ADBE Transform Group").property("ADBE Position").setValue([x0 + tw * 0.5, y0 + th * 0.5]);
        return lyr;
    }
    placeOnStage(sliceComps[2], 712, 1062, 333, 592); // Out 5 Right 9:16
    placeOnStage(sliceComps[1], 373, 1062, 333, 592); // Out 4 Center 9:16
    placeOnStage(sliceComps[0], 34,  1062, 333, 592); // Out 3 Left 9:16
    placeOnStage(compOut2,      116, 536,  848, 477); // Out 2 Far Ceiling 16:9 (Un-stretched!)
    placeOnStage(compOut1,      220, 130,  640, 360); // Out 1 Center Medallion 16:9 (Un-stretched!)

    for (var sm = 0; sm < secPrecomps.length; sm++) {
        var spm = secPrecomps[sm];
        addCompMarker(compStage, spm.sec.start - tOffset, spm.sec.b_in + " -> Sec " + spm.sec.num + ": " + spm.sec.title, spm.sec.dur);
    }

    // Attach Continuous D-Modal Audio (Master 10:45 WAV + muted Sunday Wash, or Section Continuous Slice)
    var mainAudioRel = CFG.isMaster ? CFG.masterAudioWav : CFG.sections[0].audio_stem;
    var mainAudioItem = importAsset(mainAudioRel, binAudio, 1);
    var sunAudioItem  = CFG.isMaster ? importAsset(CFG.sundayWashMp3, binAudio, 1) : null;

    var audioTargets = [compStage, compOut1, compOut2, compZ1Work, sliceComps[0], sliceComps[1], sliceComps[2]];
    for (var at = 0; at < audioTargets.length; at++) {
        var tc = audioTargets[at];
        if (sunAudioItem) {
            var sl = tc.layers.add(sunAudioItem);
            sl.name = "ALT_AUDIO_Sunday_Morning_Worship_Wash_v2 (Muted)";
            sl.audioEnabled = false;
            sl.moveToEnd();
        }
        if (mainAudioItem) {
            var ml = tc.layers.add(mainAudioItem);
            ml.name = "MASTER_AUDIO_Continuous_D_Modal_Score_v2";
            ml.audioEnabled = true;
            ml.moveToEnd();
        }
    }

    // Save BOTH Editable Project (.aep) AND After Effects Template (.aet) in the script's folder!
    var aepOut = new File(scriptFolder.fsName + "/" + CFG.projectName + ".aep");
    var aetOut = new File(scriptFolder.fsName + "/" + CFG.projectName + ".aet");
    proj.save(aepOut);
    proj.save(aetOut);
    // Re-save .aep last so active session remains the standard .aep project
    proj.save(aepOut);

    app.endSuppressDialogs(false);
})();
