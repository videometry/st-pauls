# St. Paul's Visual Experience — After Effects & Premiere Pro Template Suite

This folder (`09_After_Effects_and_Premiere_Templates`) is **automatically updated** every time a section is created or upgraded so that all rendered `Veo 3.1` loops, trimmed `VV Flow Long Loop Assembler` segments, developed St. Paul's `.ARW` archival plates, architectural alpha masks, shared bridge keyframes (`B00`–`B12`), and continuous `10m 45s` D-modal audio stems stay 100% wired in.

---

## 1. Adobe Premiere Pro (`02_Premiere_Pro_Templates_XML/`)

Open directly in **Premiere Pro (`File > Open Project...` or `File > Import...`)**:

- **Full `10m 45s` Continuous Show Project:**
  - `St_Pauls_MASTER_10m45s_All_5_Outputs_and_9x16_Stage_Premiere.xml`
- **12 Modular Per-Section Templates (`40s–60s` each):**
  - `Per_Section_Premiere_Templates/SEC01_Creation_50s_5Outputs_Premiere.xml` through `SEC12_The_Close_Altar_Mosaic_55s_5Outputs_Premiere.xml`

### Every Premiere Template Includes 7 Pre-Wired Sequences (`24 fps`):
1. `00_STAGE_5Outputs_9x16_1080x1920` — Unified `9:16` Sanctuary Stage Visualizer placing all 5 outputs once at exact **1:1 un-stretched** native aspect ratios (`Out 1 Medallion` `640×360`, `Out 2 Far Ceiling` `848×477`, `Outs 3–5 Vertical Slices` `3 × 333×592`).
2. `01_OUT1_Zone2_Center_Medallion_1920x1080`
3. `02_OUT2_Zone3_Far_Ceiling_Vault_1920x1080`
4. `03_OUT3_Zone1A_Left_Slice_1080x1920`
5. `04_OUT4_Zone1B_Center_Slice_1080x1920`
6. `05_OUT5_Zone1C_Right_Slice_1080x1920`
7. `06_WORK_Zone1_Full_Chancel_3240x1920`

Each output sequence has:
- **`V1` (Enabled):** Layer-1 Living Architecture (`Veo 3.1` seamlessly tiled section loop, or high-res Zone Concept Styleframe ready for 1-click footage swap).
- **`V2` (Muted Guide / Ready to Mask):** Layer-2 St. Paul's Upstairs `.ARW` Archival Plates on historical sections (`Sec 03, 05, 07, 08, 10`).
- **`V3` (Muted Guide):** Entry & Exit Shared Bridge Keyframes (`B00`–`B12`) locked at section boundaries—toggle the track eye icon to verify transition continuity.
- **`V4` (Muted Guide):** Architectural Line-Art Overlay (`1920×1080` / `1080×1920`)—toggle the track eye icon to check architectural alignment.
- **`A1–A2`:** Continuous `48 kHz` D-Modal Master Score (or exact sample-continuous Section Slice).
- **`A3–A4` (Muted Alternate):** Sunday Morning Worship Ambient Sound Wash v2.
- **Sequence Markers (`B00`–`B12`):** Exact section names, modal harmony, and entry/exit bridge codes.

---

## 2. Adobe After Effects (`01_After_Effects_Templates_JSX_AEP_AET/`)

Run any builder inside After Effects via **`File > Scripts > Run Script File...`** (or double-click `Compile_All_AE_Projects_and_Templates_Windows.bat` on the desktop) to build and automatically save **both `.aep` (After Effects Project) and `.aet` (After Effects Template)**:

- **Master `10m 45s` Full-Show Compiler:** `Build_St_Pauls_MASTER_10m45s_All_5_Outputs_AE.jsx`
- **12 Modular Per-Section Compilers:** `Per_Section_AE_Templates/Build_SEC01_Creation_50s_AE.jsx` .. `Build_SEC12_The_Close_Altar_Mosaic_55s_AE.jsx`

### Key After Effects Features Built Automatically:
- **Unified `3240×1920` Chancel Wall Workflow:** Animate once inside `06_WORK_CANVAS_Zone1_Full_Chancel_3240x1920` (or its per-section precomps), and **`Outputs 3, 4, and 5` (`3 × 1080×1920` `9:16` Vertical Slices)** plus **`00_STAGE_VISUALIZER_9x16_All_5_Outputs_1080x1920`** update live!
- **True AE Guide Layers (`guideLayer = true`):** Architectural line-art overlays and `B00`–`B12` bridge reference frames are flagged as **Guide Layers** so they help you align artwork in the viewport and **never accidentally burn into final projector renders**.
- **Pre-Wired Alpha Track Mattes (`TrackMatteType.ALPHA`):** Historical sections automatically mask Layer-2 archival plates inside `Walls_Only`, `Center_Large_Coffer`, `Inner_Sunburst_Core`, or `Tiffany_Last_Supper_Mosaic` (`Sec 12`), with all remaining alpha masks pre-imported into `02_ARCHITECTURAL_TEMPLATES_AND_ALPHA_MASKS`.
